#!/bin/bash

DIR=$PWD

if [ $(uname -m) == "armv7l" ] ; then

 if [ -e  ${DIR}/target_libs.tar.gz ]; then

  sudo ln -sf /usr/lib/libXdmcp.so.6.0.0 /usr/lib/libXdmcp.so.0
  sudo ln -sf /usr/lib/libXau.so.6.0.0 /usr/lib/libXau.so.0

  echo "Extracting target files to rootfs"
  sudo tar xf target_libs.tar.gz -C /

  if which lsb_release >/dev/null 2>&1 && [ "$(lsb_release -is)" = Ubuntu ]; then

    if [ ! $(which devmem2) ];then
        if ls /devmem2*_armel.deb >/dev/null 2>&1;then
          sudo dpkg -i /devmem2*_armel.deb
        fi
    fi

    if ls /devmem2*_armel.deb >/dev/null 2>&1;then
        sudo rm -f /devmem2*_armel.deb
    fi

    if [ $(lsb_release -sc) == "jaunty" ]; then
      sudo cp /opt/pvr /etc/rcS.d/S60pvr.sh
      sudo chmod +x /etc/rcS.d/S60pvr.sh
    else
      #karmic/lucid/maverick/natty etc
      sudo cp /opt/pvr /etc/init.d/pvr
      sudo chmod +x /etc/init.d/pvr
      sudo update-rc.d pvr defaults
    fi

  else

    sudo cp /opt/pvr /etc/init.d/pvr
    sudo chmod +x /etc/init.d/pvr
    sudo update-rc.d pvr defaults

  fi

 else
  echo "target_libs.tar.gz is missing"
  exit
 fi

else
 echo "This script is to be run on an armv7 platform"
 exit
fi

