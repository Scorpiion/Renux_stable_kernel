#!/bin/bash

DIR=$PWD

if [ $(uname -m) == "armv7l" ] ; then

 sudo rm /etc/powervr-esrev
 sudo depmod -a omaplfb

 if which lsb_release >/dev/null 2>&1 && [ "$(lsb_release -is)" = Ubuntu ]; then
  if [ $(lsb_release -sc) == "jaunty" ]; then
   sudo /etc/rcS.d/S60pvr.sh restart
  else
   sudo /etc/init.d/pvr restart
  fi
 else
  sudo /etc/init.d/pvr restart
 fi

else
 echo "This script is to be run on an armv7 platform"
 exit
fi

