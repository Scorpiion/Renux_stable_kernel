/******************************************************************************

 @File         Uniform.cpp

 @Title        Texture

 @Copyright    Copyright (C)  Imagination Technologies Limited.

 @Platform     Independent

 @Description  Texture container for OGLES2

******************************************************************************/
#include "Uniform.h"

namespace pvrengine
{

}

/******************************************************************************
End of file (Uniform.cpp)
******************************************************************************/
