/******************************************************************************

 @File         UniformBase.cpp

 @Title        Texture

 @Copyright    Copyright (C)  Imagination Technologies Limited.

 @Platform     Independent

 @Description  Texture container for OGLES2

******************************************************************************/
namespace pvrengine
{




}

/******************************************************************************
End of file (UniformBase.cpp)
******************************************************************************/
