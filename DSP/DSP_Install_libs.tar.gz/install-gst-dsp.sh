#!/bin/bash

DIR=$PWD

function no_connection {

echo "setup internet connection before running.."
exit

}

if [ $(uname -m) == "armv7l" ] ; then

ping -c 1 -w 100 www.google.com  | grep "ttl=" || no_connection

sudo apt-get -y install git-core pkg-config build-essential gstreamer-tools libgstreamer0.10-dev

mkdir -p ${DIR}/git/

if ! ls ${DIR}/git/gst-dsp >/dev/null 2>&1;then
cd ${DIR}/git/
git clone git://github.com/felipec/gst-dsp.git
fi

cd ${DIR}/git/gst-dsp
make clean
git pull
make CROSS_COMPILE= 
sudo make install
cd ${DIR}/

if ! ls ${DIR}/git/gst-omapfb >/dev/null 2>&1;then
cd ${DIR}/git/
git clone git://github.com/felipec/gst-omapfb.git
fi

cd ${DIR}/git/gst-omapfb
make clean
git pull
make CROSS_COMPILE= 
sudo make install
cd ${DIR}/

if ! ls ${DIR}/git/dsp-tools >/dev/null 2>&1;then
cd ${DIR}/git/
git clone git://github.com/felipec/dsp-tools.git
fi

cd ${DIR}/git/dsp-tools
make clean
git checkout master -f
git pull
git branch -D firmware-tmp || true
git checkout origin/firmware -b firmware-tmp
sudo cp -v firmware/test.dll64P /lib/dsp/
git checkout master -f
git branch -D firmware-tmp || true
make CROSS_COMPILE= 
sudo make install
cd ${DIR}/

else
 echo "This script is to be run on an armv7 platform"
 exit
fi

