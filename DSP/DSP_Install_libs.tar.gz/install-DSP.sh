#!/bin/bash

DIR=$PWD

if [ $(uname -m) == "armv7l" ] ; then

 if [ -e  ${DIR}/dsp_libs.tar.gz ]; then

  echo "Extracting target files to rootfs"
  sudo tar xf dsp_libs.tar.gz -C /

  if which lsb_release >/dev/null 2>&1 && [ "$(lsb_release -is)" = Ubuntu ]; then

    if [ $(lsb_release -sc) == "jaunty" ]; then
      sudo cp /opt/dsp /etc/rcS.d/S61dsp.sh
      sudo chmod +x /etc/rcS.d/S61dsp.sh
    else
      #karmic/lucid/maverick/etc
      sudo cp /opt/dsp /etc/init.d/dsp
      sudo chmod +x /etc/init.d/dsp
      sudo update-rc.d dsp defaults
    fi

  else

    sudo cp /opt/dsp /etc/init.d/dsp
    sudo chmod +x /etc/init.d/dsp
    sudo update-rc.d dsp defaults

  fi

 else
  echo "dsp_libs.tar.gz is missing"
  exit
 fi

else
 echo "This script is to be run on an armv7 platform"
 exit
fi

